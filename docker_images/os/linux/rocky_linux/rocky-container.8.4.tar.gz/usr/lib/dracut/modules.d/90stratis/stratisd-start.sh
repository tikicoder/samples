#!/bin/sh

stratisd-init --debug > /dev/kmsg 2>&1 &